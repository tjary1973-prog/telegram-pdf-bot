import telebot

TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "مرحباً! أرسل لي ملف PDF وسأقوم بتحويله.")

@bot.message_handler(content_types=['document'])
def handle_docs(message):
    bot.reply_to(message, "تم استلام الملف! (هنا نضيف كود التحويل لاحقاً)")

bot.polling()
